Tool Script für den SBUS-Switch (nur für "Horus"-Sender mit Farbdisplay wie X10, X12s, TX16s usw.)
Das Script erstellt diese Einstellungen:
- Mischer für den Mode Einzelkanal
- Einstellungen im Servo-Menue
- Erstellt die Kurve
Pro SBUS-Switch muss das Script 1x ausgeführt werden
Die Einstellung "Erweiterte Wege" muss bei Bedarf vorher im Modell-Menue aktiviert werden
Das Script und der gleichnamige Ordner muss auf die SD-Karte in den Ordner \SCRIPTS\TOOLS\ kopiert werden
Ausführen über 'System' > 'Tools'

