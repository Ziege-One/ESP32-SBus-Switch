---- #########################################################################
---- #                                                                       #
---- # Copyright (C) OpenTX                                                  #
-----#                                                                       #
---- # License GPLv2: http://www.gnu.org/licenses/gpl-2.0.html               #
---- #                                                                       #
---- # This program is free software; you can redistribute it and/or modify  #
---- # it under the terms of the GNU General Public License version 2 as     #
---- # published by the Free Software Foundation.                            #
---- #                                                                       #
---- # This program is distributed in the hope that it will be useful        #
---- # but WITHOUT ANY WARRANTY; without even the implied warranty of        #
---- # MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
---- # GNU General Public License for more details.                          #
---- #                                                                       #
---- #########################################################################


 
---- # Change log:                                                      
---- # 32 Kanäle
---- # opt Code for delete mixes
---- # Inputs nicht löschen
---- # FlySky Receivers zwingend Mode Kompatibel 
---- # Schalter SI und SJ rausgenommen
---- # Zuordnung Kurve im Mischer = "SBUS_Channel_PAGE[2][5] + 1"
---- # Das Script sucht sich jetzt die Source ID für "MAX" selbst (getFieldInfo)
---- # Layout und Wording
---- # Anpassungen bei Kurve
---- # 
---- # 
---- # 
---- # getestet mit openTX 2.3, edgeTX 2.5, edgeTX 2.6



local VALUE = 0
local COMBO = 1

local edit = false
local page = 1
local current = 1
local pages = {}
local fields = {}

-- load common Bitmaps
local BackgroundImg = Bitmap.open("SBUS_Switch/background.png")
local ImgPageUp = Bitmap.open("SBUS_Switch/pageup.png")
local ImgPageDn = Bitmap.open("SBUS_Switch/pagedn.png")


-- Change display attribute to current field
local function addField(step)
  local field = fields[current]
  local min, max
  if field[3] == VALUE then
    min = field[6]
    max = field[7]
  elseif field[3] == COMBO then
    min = 0
    max = #(field[6]) - 1
  end
  if (step < 0 and field[5] > min) or (step > 0 and field[5] < max) then
    field[5] = field[5] + step
  end
end

local function umlaut(s)  -- umlaute ermöglichen
-- 152 Ä
-- 153 ä
-- 154 Ö
-- 155 ö
-- 156 Ü
-- 157 ü
-- 158 ß

s = string.gsub(s, "ae", string.char(153))
-- s = string.gsub(s, "ae", "ae")
s = string.gsub(s, "oe", string.char(155))
s = string.gsub(s, "ue", string.char(157))
return s

-- Aufruf:
-- local Text = "Tuer"
-- Text = umlaut(Text)
-- Beispiel im Script:
-- local Text = "Tuer"
-- lcd.drawText(0,0,umlaut(Text),LEFT+SMLSIZE+CUSTOM_COLOR)
end

-- Select the next or previous page
local function selectPage(step)
  page = 1 + ((page + step - 1 + #pages) % #pages)
  edit = false
  current = 1
end

-- Select the next or previous editable field
local function selectField(step)
  repeat
    current = 1 + ((current + step - 1 + #fields) % #fields)
  until fields[current][4]==1
end

-- Redraw the current page
local function redrawFieldsPage(event)

  for index = 1, 10, 1 do
    local field = fields[index]
    if field == nil then
      break
    end

    local attr = current == (index) and ((edit == true and BLINK or 0) + INVERS) or 0
    attr = attr + TEXT_COLOR

    if field[4] == 1 then
      if field[3] == VALUE then
        lcd.drawNumber(field[1], field[2], field[5], LEFT + attr)
      elseif field[3] == COMBO then
        if field[5] >= 0 and field[5] < #(field[6]) then
          lcd.drawText(field[1],field[2], field[6][1+field[5]], attr)
        end
      end
    end
  end
end

local function updateField(field)
  local value = field[5]
end

-- Main
local function runFieldsPage(event)
  if event == EVT_VIRTUAL_EXIT then -- exit script
    return 2
  elseif event == EVT_VIRTUAL_ENTER then -- toggle editing/selecting current field
    if fields[current][5] ~= nil then
      edit = not edit
      if edit == false then
        updateField(fields[current])
      end
    end
  elseif edit then
    if event == EVT_VIRTUAL_INC or event == EVT_VIRTUAL_INC_REPT then
      addField(1)
    elseif event == EVT_VIRTUAL_DEC or event == EVT_VIRTUAL_DEC_REPT then
      addField(-1)
    end
  else
    if event == EVT_VIRTUAL_NEXT then
      selectField(1)
    elseif event == EVT_VIRTUAL_PREV then
      selectField(-1)
    end
  end
  redrawFieldsPage(event)
  return 0
end

-- set visibility flags starting with SECOND field of fields
local function setFieldsVisible(...)
  local arg={...}
  local cnt = 2
  for i,v in ipairs(arg) do
    fields[cnt][4] = v
    cnt = cnt + 1
  end
end

-- draws one letter mark
local function drawMark(x, y, name)
  lcd.drawBitmap(ImgMarkBg, x, y)
  lcd.drawText(x+8, y+3, name, TEXT_COLOR)
end

-- fields format : {[1]x, [2]y, [3]COMBO, [4]visible, [5]default, [6]{values}}
-- fields format : {[1]x, [2]y, [3]VALUE, [4]visible, [5]default, [6]min, [7]max}
local SBUS_Channel_PAGE = {
  {50, 50, COMBO, 1, 15, { "CH1", "CH2", "CH3", "CH4", "CH5", "CH6", "CH7", "CH8", "CH9", "CH10", "CH11", "CH12", "CH13", "CH14", "CH15", "CH16", "CH17", "CH18", "CH19", "CH20", "CH21", "CH22", "CH23", "CH24", "CH25", "CH26", "CH27", "CH28", "CH29", "CH30", "CH31", "CH32" } },   --[5]default is here 4 = CH5
  {50, 110, COMBO, 1, 0, { "CV1", "CV2", "CV3", "CV4", "CV5", "CV6", "CV7", "CV8", "CV9", "CV10", "CV11", "CV12", "CV13", "CV14", "CV15", "CV16" } },   --[5]default is here 0 = CV1
  {50, 170, COMBO, 1, 0, { "Normal", "Kompatibel" } },   --[5]default is here 0 = Normal
  {50, 230, COMBO, 1, 0, { "FrSky", "FlySky" } },   --[5]default is here 0 = FrSky
}

--local ImgCopter

local function runChannelConfig(event)
  lcd.clear()
  lcd.drawBitmap(BackgroundImg, 0, 0)
  lcd.drawBitmap(ImgPageDn, 455, 95)
  --lcd.drawBitmap(ImgCopter, 200, 50)
  fields = SBUS_Channel_PAGE
  
  lcd.drawText(40, 20, "Kanal ?", TEXT_COLOR)
  lcd.drawFilledRectangle(40, 45, 100, 30, TEXT_BGCOLOR)
  lcd.drawText(40, 80, "Kurve Nr. ?", TEXT_COLOR)
  lcd.drawFilledRectangle(40, 105, 100, 30, TEXT_BGCOLOR)
  lcd.drawText(40, 140, "Mode ?", TEXT_COLOR)
  if fields[3][5] == 0 then 
	lcd.drawText(170, 150, "Achtung: bei Mode Normal", TEXT_COLOR)
	lcd.drawText(170, 170, "erst erweiterte Wege einstellen", TEXT_COLOR)
  end
  lcd.drawFilledRectangle(40, 165, 100, 30, TEXT_BGCOLOR)
  local Text = "Empfaenger ?"  -- Umweg zur Darstellung von Umlauten nütig
  lcd.drawText(40, 200,umlaut(Text), TEXT_COLOR)
  lcd.drawFilledRectangle(40, 225, 100, 30, TEXT_BGCOLOR)
  if fields[4][5] == 1 then 
    lcd.drawText(170, 210, "Achtung: fuer FlySky Empfaenger", TEXT_COLOR)
	lcd.drawText(170, 230, "erst erweiterte Wege einstellen", TEXT_COLOR)
  end
  
  if fields[4][5] == 1 then -- wenn FlySky dann zwingend "Mode Kompatibel"
	fields[3][5]=1
  end

-- only for developing  
--  local fieldinfo = getFieldInfo('max')
  -- lcd.drawText(230,1,"getFieldInfo('max')",0)
    -- lcd.drawText(230,21,"id: ", 0)
    -- lcd.drawText(300,21,fieldinfo['id'],0)
    -- lcd.drawText(230,41,"name: ", 0)
    -- lcd.drawText(300,41,fieldinfo['name'],0)
    -- lcd.drawText(230,61,"desc: ", 0)
    -- lcd.drawText(300,61,fieldinfo['desc'],0)
	  
  
  local result = runFieldsPage(event)
  return result
end

-- fields format : {[1]x, [2]y, [3]COMBO, [4]visible, [5]default, [6]{values}}
-- fields format : {[1]x, [2]y, [3]VALUE, [4]visible, [5]default, [6]min, [7]max}
local SwitchFields = {
  {50, 170, COMBO, 1, 0, { "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH" } },    --[5]default is here 0 = SA
  {150, 170, COMBO, 1, 1, { "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH" } },   --[5]default is here 1 = SB 
  {250, 170, COMBO, 1, 2, { "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH" } },   --[5]default is here 2 = SC 
  {350, 170, COMBO, 1, 3, { "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH" } },  --[5]default is here 3 = SD 
  {50, 230, COMBO, 1, 4, { "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH" } },   --[5]default is here 4 = SE
  {150, 230, COMBO, 1, 5, { "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH" } },  --[5]default is here 5 = SF 
  {250, 230, COMBO, 1, 6, { "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH" } },   --[5]default is here 6 = SG 
  {350, 230, COMBO, 1, 7, { "SA", "SB", "SC", "SD", "SE", "SF", "SG", "SH" } },  --[5]default is here 7 = SH  
}


local function runSwitchConfig(event)
  lcd.clear()
 
  lcd.drawBitmap(BackgroundImg, 0, 0)
  lcd.drawBitmap(ImgPageUp, 0, 95)
  lcd.drawBitmap(ImgPageDn, 455, 95)
 
  lcd.drawText(40, 25, "Schalter fuer Ausgaenge zuordnen.", TEXT_COLOR)
  lcd.drawText(40, 50, "Ggf. nachtraeglich in den Mischern anpassen", TEXT_COLOR)
  lcd.drawText(40, 75, "um andere Schalterpositionen", TEXT_COLOR)
  lcd.drawText(40, 100, "oder logische Schalter auszuwaehlen", TEXT_COLOR)

 fields = SwitchFields
  lcd.drawText(40, 140, "Ausgang 1", TEXT_COLOR)
  lcd.drawFilledRectangle(40, 165, 40, 30, TEXT_BGCOLOR)
  lcd.drawText(140, 140, "Ausgang 2", TEXT_COLOR)
  lcd.drawFilledRectangle(140, 165, 40, 30, TEXT_BGCOLOR)  

  lcd.drawText(240, 140, "Ausgang 3", TEXT_COLOR)
  lcd.drawFilledRectangle(240, 165, 40, 30, TEXT_BGCOLOR)
  lcd.drawText(340, 140, "Ausgang 4", TEXT_COLOR)
  lcd.drawFilledRectangle(340, 165, 40, 30, TEXT_BGCOLOR)  

  lcd.drawText(40, 200, "Ausgang 5", TEXT_COLOR)
  lcd.drawFilledRectangle(40, 225, 40, 30, TEXT_BGCOLOR)
  lcd.drawText(140, 200, "Ausgang 6", TEXT_COLOR)
  lcd.drawFilledRectangle(140, 225, 40, 30, TEXT_BGCOLOR)  

  lcd.drawText(240, 200, "Ausgang 7", TEXT_COLOR)
  lcd.drawFilledRectangle(240, 225, 40, 30, TEXT_BGCOLOR)
  lcd.drawText(340, 200, "Ausgang 8", TEXT_COLOR)
  lcd.drawFilledRectangle(340, 225, 40, 30, TEXT_BGCOLOR)  
    
  local result = runFieldsPage(event)
  return result
end


local ConfigSummaryFields = {
  {100, 220, COMBO, 1, 0, { "  passt noch nicht?  ", "  passt! - ab damit  "} },
}

local ImgSummary

local function runConfigSummary(event)
  lcd.clear()
  if ImgSummary == nil then
    ImgSummary = Bitmap.open("SBUS_Switch/summary.png")
  end
  fields = ConfigSummaryFields
  lcd.drawBitmap(BackgroundImg, 0, 0)
  lcd.drawBitmap(ImgPageUp, 0, 95)
  lcd.drawBitmap(ImgSummary, 300, 60)
  lineIndex = 40
  -- Channel
  lcd.drawText(40, 40, "Kanal", TEXT_COLOR)
  lcd.drawText(180, 40, ": CH" .. SBUS_Channel_PAGE[1][5] + 1, TEXT_COLOR)
  -- Kurve
  lcd.drawText(40, 60, "Kurve", TEXT_COLOR)
  lcd.drawText(180, 60, ": CV" .. SBUS_Channel_PAGE[2][5] + 1, TEXT_COLOR)
  -- Mode
  lcd.drawText(40, 80, "Mode", TEXT_COLOR)
	if SBUS_Channel_PAGE[3][5] == 0 then
	  lcd.drawText(180, 80, ": Normal", TEXT_COLOR)
	elseif SBUS_Channel_PAGE[3][5] == 1 then
	  lcd.drawText(180, 80, ": Kompatibel", TEXT_COLOR)
	end
  -- Empfaenger
  lcd.drawText(40, 100, "Empfaenger", TEXT_COLOR)
	if SBUS_Channel_PAGE[4][5] == 0 then
	  lcd.drawText(180, 100, ": FrSky", TEXT_COLOR)
	elseif SBUS_Channel_PAGE[4][5] == 1 then
	  lcd.drawText(180, 100, ": FlySky", TEXT_COLOR)
	end

	

  local result = runFieldsPage(event)
  if(fields[1][5] == 1 and edit == false) then
    selectPage(1)
  end
  return result
end

local function addMix(channel, input, name, weight, index)
  local fieldinfo = getFieldInfo('max')   -- Source ID fuer "MAX" suchen lassen, je nach LUA Version und Sender unterschiedlich
  local mix = { source = fieldinfo['id'], name=name, switch = input, carryTrim = 0, curveType = 3, curveValue = SBUS_Channel_PAGE[2][5] + 1 }
  if weight ~= nil then
    mix.weight = weight
  end
  if input == nil then
    mix.input = input
  end
  if index == nil then
    index = 0
  end
  model.insertMix(channel, index, mix)
end

local function createSBUS_Switch(event)
  lcd.clear()
  lcd.drawBitmap(BackgroundImg, 0, 0)
  lcd.drawBitmap(ImgSummary, 300, 60)
  --model.defaultInputs()
  --model.deleteMixes()
  
  -- define curve
--  local val = model.setCurve(SBUS_Channel_PAGE[2][5], {name = "SBS", y={-25,0, 25}})
  model.setCurve(SBUS_Channel_PAGE[2][5], {name = "SBS", y={-25,0, 25}})
  
  -- Output
  if SBUS_Channel_PAGE[3][5] == 0 then -- Normal
	if SBUS_Channel_PAGE[4][5] == 0 then -- FrSky
		model.setOutput(SBUS_Channel_PAGE[1][5], {min = -1250, max = 1250, ppmCenter = 20})
	end
  elseif SBUS_Channel_PAGE[3][5] == 1 then -- Kompatibel
	if SBUS_Channel_PAGE[4][5] == 0 then -- FrSky
		model.setOutput(SBUS_Channel_PAGE[1][5], {min = -999, max = 1000, ppmCenter = 20})
	elseif SBUS_Channel_PAGE[4][5] == 1 then -- FlySky
		model.setOutput(SBUS_Channel_PAGE[1][5], {min = -1024, max = 1024, ppmCenter = 0})
	end
  end
    
  -- mixers and switches
  for delmix = 1,22,1 do
	model.deleteMix(SBUS_Channel_PAGE[1][5],0)
  end
  
  addMix(SBUS_Channel_PAGE[1][5], SwitchFields[8][5] * 3 + 1, "Ausg8",400)
  addMix(SBUS_Channel_PAGE[1][5], SwitchFields[7][5] * 3 + 1, "Ausg7",200)
  addMix(SBUS_Channel_PAGE[1][5], SwitchFields[6][5] * 3 + 1, "Ausg6",100)
  addMix(SBUS_Channel_PAGE[1][5], SwitchFields[5][5] * 3 + 1, "Ausg5",50)
  addMix(SBUS_Channel_PAGE[1][5], SwitchFields[4][5] * 3 + 1, "Ausg4",25)
  addMix(SBUS_Channel_PAGE[1][5], SwitchFields[3][5] * 3 + 1, "Ausg3",12)
  addMix(SBUS_Channel_PAGE[1][5], SwitchFields[2][5] * 3 + 1, "Ausg2",6)
  addMix(SBUS_Channel_PAGE[1][5], SwitchFields[1][5] * 3 + 1, "Ausg1",3)
  addMix(SBUS_Channel_PAGE[1][5], 0 , "offset",-398)
  
  return 2
end

-- Init
local function init()
  current, edit = 1, false
  pages = {
    runChannelConfig,
	runSwitchConfig,
    runConfigSummary,
    createSBUS_Switch,
  }
end

-- Main
local function run(event)
  if event == nil then
    error("Cannot be run as a model script!")
    return 2
  elseif event == EVT_VIRTUAL_NEXT_PAGE and page < #pages-1 then
    selectPage(1)
  elseif event == EVT_VIRTUAL_PREV_PAGE and page > 1 then
    killEvents(event);
    selectPage(-1)
  end
  
  local result = pages[page](event)
  return result
end

return { init=init, run=run }
